# Data-Cleaning-and-Exploration-Project  
BUSINESS UNDERSTANDING  
We were given a Data frame which consisted of 14 columns and 1000 rows and were asked to explore the data. 
Python is the primary tool used for the data exploration. This assignment is primarily interested in my ability to understand the data. 
I’ve broken this report as per the ‘Task #s’ given to us in the problem statement.  

> I. Data Quality Report  
 II. Numerical Data Analysis  
 III. Categorical Data Analysis  
 IV. Visuals

